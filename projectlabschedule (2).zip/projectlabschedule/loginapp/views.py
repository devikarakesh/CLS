from django.shortcuts import render,redirect
from django.views import View
from django.contrib.auth import authenticate
from .models import Userprofile,Token
from django.contrib import messages
import json
from administrator.models import notifications

from administrator.forms import AddStudentform
from .models import *
from django.http import HttpResponse


# Create your views here.

class Homepageview(View):
 def get(self,request):
  n=notifications.objects.all()
  return render(request,'mainhome.html',{'n':n})
 
class Loginpageview(View):
  def get(self,request):
   return render(request,'mlog1.html')
  def post(self,request):
    user_type=""
    response_dict={"success":False}
    landing_page_url={
      "ADMIN":"administrator",
      "FACULTY":"user:loadinstitute",
      "STUDENT":"student",
      "LABSTAFF":"staff"
    }
    username=request.POST.get("username")
    password=request.POST.get("password")
    print(username)
    authenticated=authenticate(username=username,password=password)
    try:
      user=Userprofile.objects.get(username=username)
      print("hel")
    except Userprofile.DoesNotexist:
      response_dict[
        "reason"
      ]="No account found fpr this username.Please signup"
      messages.error(request,response_dict["reason"])
    if not authenticated:
        response_dict["reason"]="Invalid credentials"
        messages.error(request,response_dict["reason"])
        return redirect(request.GET.get("from")or "user:login")
    else:
      print("hello")
      session_dict={"real_user":authenticated.id}
      token,c=Token.objects.get_or_create(
        user=user,defaults={"session_dict":json.dumps(session_dict)}
      )
      user_type=authenticated.user_type
      print("hai")
      print(user)
      print(user_type)
      return redirect(landing_page_url[user_type])
    return redirect(request.GET.get("from") or  loadlogin)
      
    
  
 
class Adminpage(View):
 def get(self,request):
  return render(request,'admin/admin.html')


class Labstaff(View):
  def get(self,request):
   return render(request,'staff/staffdashboard.html')

class Faculty(View):
  def get(self,request):
    return render(request,'faculty/facultydashboard.html')
  


class ViewStudent(View):
  def get(self,request):
    return render(request,'admin/viewstudent.html')

class Student(View):
 def get(self,request):
  return render(request,'student/studentdashboard.html')
 
class Studentreg(View):
  def get(self,request):
    return render(request,'admin/Student.html')

  def post(self,request):
        form=AddStudentform(request.POST)
        if form.is_valid():
            reg_form=form.save(commit=False)
            rf=Userprofile.objects.create_user(user_type='Student',username=request.POST['username'],password=request.POST['password'])
            reg_form.loginid=rf
            rf.save()
            reg_form.save()
        return HttpResponse('''<script>alert("added");window.location="/viewstudent/"</script>''')
            

class Updatestudent(View):
    def get(self,request,id):
        n=Student.objects.get(id=id)
        return render(request,'admin/updatestudent.html',{'n':n})
    def post(self,request,id):
        n=Student.objects.get(id=id)
        form=UpdateStudentform(request.POST,instance=n)
        if form.is_valid():
            form.save()
            return redirect('viewstudent')



class Staffreg(View):
  def get(self,request):
    return render(request,'admin/staffregister.html')
  def post(self,request,id):
        s=Student.objects.get(id=id)
        form=UpdateStudentform(request.POST,instance=n)
        if form.is_valid():
            form.save()
            return redirect('viewstudent')
  
class Updatestudent(View):
    def get(self,request,id):
        n=Student.objects.get(id=id)
        return render(request,'admin/updatestudent.html',{'n':n})
    def post(self,request,id):
        n=Student.objects.get(id=id)
        form=UpdateLabstaffform(request.POST,instance=n)
        if form.is_valid():
            form.save()
            return redirect('viewstudent')




class AdminBasepage(View):
 def get(self,request):
  return render(request,'admin/adminbase.html')
 

class ViewStaff(View):
  def get(self,request):
    return render(request,'admin/viewstaff.html')
  


class Addnotifications(View):
  def get(self,request):
    return render(request,'admin/addnotification.html')



class Logout(View):
    def get(self,request):
        request.session["token"]=None
        request.session.flush()
        return redirect("login")