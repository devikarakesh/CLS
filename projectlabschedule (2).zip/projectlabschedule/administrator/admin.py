from django.contrib import admin
from administrator.models import *

# Register your models here.
admin.site.register(notifications)
admin.site.register(Faculty1)
admin.site.register(Subject1)
admin.site.register(TimetableEntry1)
admin.site.register(Class1)
admin.site.register(WorkingDay)
admin.site.register(TimeSlot)
admin.site.register(Staffnotification)
admin.site.register(Feedback)
admin.site.register(Staff)
admin.site.register(Student)


