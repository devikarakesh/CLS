from django.shortcuts import render
from django.views import View


# Create your views here.

class Homepageview(View):
 def get(self,request):
  return render(request,'mainhome.html')
 
class Loginpageview(View):
  def get(self,request):
   return render(request,'mlog1.html')
 
class Adminpage(View):
 def get(self,request):
  return render(request,'admin/admin.html')

class Student(View):
 def get(self,request):
  return render(request,'admin/student.html')
 
class Labstaff(View):
  def get(self,request):
   return render(request,'admin/staffregister.html')
 