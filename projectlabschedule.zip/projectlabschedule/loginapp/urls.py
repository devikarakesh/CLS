from django.urls import path
from .views import *
urlpatterns = [
    path('',Homepageview.as_view(),name='homepage'),
    path('login/',Loginpageview.as_view(),name='login'),
    path('administrator/',Adminpage.as_view(),name='administrator'),
    path('Studentregister/',Student.as_view(),name='studentregister'),
    path('Staffregister/',Labstaff.as_view(),name='staffregister'),

   
]
